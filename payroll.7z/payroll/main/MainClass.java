package com.cg.payroll.main;

import com.cg.payroll.bean.Associate;
import com.cg.payroll.bean.Bank;
import com.cg.payroll.bean.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass{

	public static void main(String[] args) {
		PayrollServicesImpl payrollServices=new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails("Shravan", "kumar", "shravan.com", "java", "analyst", "IJSJKLASJ", 1000000, 15015, 500, 500, 146541566, "vskp", "CITI0092");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		System.out.println(payrollServices.getAssociateDetails(associateId).getLastName());
		System.out.println("Salary  :"+payrollServices.calculateNetSalary(associateId));
		System.out.println("Monthly Tax :"+payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());
		System.out.println("Net Salary :"+payrollServices.getAssociateDetails(associateId).getSalary().getNetSalary());
}
}

























//		int yearlyInvestment=50000;
//		String firstName="Shravan";
//		Associate associate=searchAssociateId(yearlyInvestment,firstName);
//		if(associate!=null)
//		System.out.println(associate.getFirstName()+" has greater than "+yearlyInvestment);
//		else
//		System.out.println("Not found");
//		}
//		public static Associate searchAssociateId(int yearlyInvestment,String firstName){
//		Associate[] associateteam=new Associate[5];
//		associateteam[0]=new Associate(101, 60000, "Shravan", "Kumar", "java", "Analyst", "ILAKSJLKLAS", "abc@asd.com",new Salary(15000, 500, 1000, 2000, 500, 200, 1000, 1000, 100, 17000, 15500),new Bank(12121212,"CITI","CITI000021")) ;
//		associateteam[1]=new Associate(102, 8000, "Chitraksh", "Singisetti", "Java", "Analyst", "NJIH8659HGJ", "def@abc.com",new Salary(15000, 500, 1000, 2000, 500, 100, 2000, 13000, 1030, 17040, 16500),new Bank(12121222,"CITI","CITI000022"));
//		associateteam[2]=new Associate();
//		for (Associate associate : associateteam) 
//		if(associate!=null&&associate.getFirstName()==firstName&&associate.getYearlyInvestmentUnder80C()>=yearlyInvestment)
//		return associate;
//		return null;
//		}
		
//}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	//	int associateIdToBeSearch=222;
	//	Associate associate=searchAssociate(associateIdToBeSearch);
	//	if(associate!=null)
	//		System.out.println(associate.getFirstName()+" "+associate.getLastName());
	//	else
	//		System.out.println("associate details with Id"+associateIdToBeSearch+"Not found");
	  //  }
//public static Associate searchAssociate(int associateID){
	//	Associate [] associates=new Associate[5];
	//	associates[0] = new Associate(111, 25000, "Shravan", "Kumar", "java", "Analyst", "ILASNJ717", "abc.com");
	//	associates[1] = new Associate(222, 10000, "Sindhu", "Kalakonda", "java", "Analyst", "ILASNJ717", "abc.com");
	//	for(Associate associate : associates){
	//		if(associate!=null&&associate.getAssociateId()==associateID)
	//			return associate;
	//		if(associate.getFirstName()=="Shravan"&&associate.getYearlyInvestmentUnder80C()==25000);
	//			System.out.println(associate.getEmailId());
			
	//	}
	//	return null;
//}		

//}		
		
		
		
		
		
		
		
//		Associate associate1=new Associate();
//		associate1.setFirstName("shravan");
//		Associate associate2 = new Associate(101,150000,"shravan","kumar","java","analyst","500090","asdf.com");
//		Associate associate3 = new Associate(102,150000,"sindhu","kalakonda","java","analyst","500090","asdf.com");

//		System.out.println(associate1.getFirstName());
//		System.out.println(associate3.getFirstName());

//	}

//}
